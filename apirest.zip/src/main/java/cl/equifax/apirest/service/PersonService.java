package cl.equifax.apirest.service;

import cl.equifax.apirest.dto.PersonDTO;
import cl.equifax.apirest.mapper.PersonMapper;
import cl.equifax.apirest.model.Person;
import cl.equifax.apirest.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonService {

    private final PersonRepository personRepository;
    private final PersonMapper personMapper;

    @Autowired
    public PersonService(PersonRepository personRepository, PersonMapper personMapper) {
        this.personRepository = personRepository;
        this.personMapper = personMapper;
    }

    public PersonDTO findByRut(String rut) {
        Person person = personRepository.findByRut(rut)
                .orElseThrow(() -> new RuntimeException("Person not found"));
        return personMapper.toDto(person);
    }

    public PersonDTO savePerson(PersonDTO personDTO) {
        Person person = personMapper.toEntity(personDTO);
        person = personRepository.save(person);
        return personMapper.toDto(person);
    }
}